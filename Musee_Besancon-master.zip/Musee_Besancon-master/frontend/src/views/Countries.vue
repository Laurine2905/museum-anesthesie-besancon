<template>
  <div>
    <h2>Les pays</h2>
    <country-list />
  </div>
</template>

<script setup>
import CountryList from "@/components/CountryList.vue";
</script>
