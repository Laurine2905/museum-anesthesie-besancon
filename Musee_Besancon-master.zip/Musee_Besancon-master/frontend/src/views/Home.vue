<template>
  <div>
    <h2>Utilitaires Backend</h2>
    <HelloWorld />
  </div>
  <div><img  alt="Vue logo" src="../assets/logo.png" /></div>
</template>

<script setup>
import HelloWorld from "@/components/HelloWorld.vue";
</script>
