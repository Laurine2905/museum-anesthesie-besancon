<template>
  <div>
  <h2>Appel AJAX</h2>
  <RestClient />
  </div>
</template>

<script setup>
import RestClient from "@/components/RestClient.vue";
</script>

