<template>
  <div>
    <h2>This is an about page</h2>
  </div>
</template>

