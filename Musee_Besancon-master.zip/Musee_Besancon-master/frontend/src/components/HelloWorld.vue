<template>
  <div>
    <ul>
      <li><a href="http://localhost:8989/swagger-ui/index.html" target="_blank">Swagger</a></li>
      <li><a href="http://localhost:8989/h2-console" target="_blank">Console H2 (URL jdbc:h2:mem:testdb)</a></li>
    </ul>
  </div>
</template>
